#include <stdio.h>
#include <stdlib.h>
#include "sokoban.h"

int main(int argc, char const *argv[])
{
	char getstring[MAXCH+1];
	Boolean boucle=TRUE;
	int score=0;
	int i=0;

	position spos;
	grille stat={
	"###########",
	"###  #  o #",
	"##  O   ###",
	"##     O###",
	"## S     ##",
	"##       ##",
	"##       ##",
	"##      o##",
	"###########"
	};

	/* copie grille */
	grille dyn;
	copiegrille2(stat,dyn);

	affichegrille(stat);
	affichegrille(dyn);

	/* position sokoban*/
	if (getSokoban(stat).x==0 && getSokoban(stat).y==0)
		error(NO_SOKOBAN);
	else{
		spos=getSokoban(stat);
		printf("position sokoban x=%d y=%d\n",spos.x,spos.y);
	}

	if (verifcompt(stat)==TRUE)
		error(NO_EQ);

   aide();
	
	 while (boucle==TRUE) {
     affichegrille(stat);
     score++;
     printf("\n>");

     fgetgetstring(getstring);

     for(i=0;getstring[i+1]!='\0';i++){
           switch(getstring[i])
              {
                 case QUITTER:
                 boucle=FALSE;
                 break;
                 case HELP:
                 aide();
                 break;
                 case HAUT:
                 spos=joue(stat, getstring[i], getSokoban(stat), dyn);
                 break;
                 case BAS:
                 spos=joue(stat, getstring[i], getSokoban(stat), dyn);
                 break;
                 case GAUCHE:
                 spos=joue(stat, getstring[i], getSokoban(stat), dyn);
                 break;
                 case DROITE:
                 spos=joue(stat, getstring[i], getSokoban(stat), dyn);
                 break;
                 default:
                 printf("getstring inconnue\n");
              }

           if(gagne(stat, getSokoban(stat), dyn) == TRUE)
           {
              boucle = FALSE;
              affichegrille(stat);
              printf(" you win in %d games \n", score);
           }
        }
  }
  return 0;
}

	
	


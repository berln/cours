#include <stdio.h>
#include <stdlib.h>
#include "sokoban.h"

position  getSokoban(grille l){
	int i;
	int j;
	position res;
	res.x=0;
	res.y=0;
	for (i = 0; i < HAUTEUR; ++i)
	{
		for (j= 0; j < LARGEUR; ++j)
		{
			/* code */
			
				if (l[i][j]==SOKOBAN)
			{
				printf("trouver @ i=%d j=%d\n",i,j);
				res.x=i;
				res.y=j;
			}
		}		
	}
	return res;
}

 void error(CodeErreur code)
  {
    switch (code) {
     case NO_SOKOBAN : fprintf(stderr,"pas de sokoban!\n"); break;
     case NO_LIGNE	: fprintf(stderr,"erreur taille ligne !\n"); break;
     case NO_EQ	: fprintf(stderr,"inegalitée caisse cible !\n"); break;
     case NO_GETSTRING	: fprintf(stderr,"inegalitée caisse cible !\n"); break;
     case PAUS_E	:	fprintf(stderr,"pos nok !\n"); break;
     case EMUR	:	fprintf(stderr,"pos mur !\n"); break;
     case ECAISSE	:	fprintf(stderr,"pos caisse !\n"); break;
     default: fprintf(stderr,"code erreur inconnu!\n");
    }
    exit(code);
  }/*error*/

void  affichegrille(grille l){
	int i;
	for (i = 0; i < HAUTEUR; ++i)
	{
		/* code */
		printf("%s\n",l[i] );
	}
}

void copiegrille2(grille l, grille m){
	int i;
	int j;

	/*verification taille grille*/
	if (verif(l)==1)
		error(NO_LIGNE);
	/*copie grille*/
	for (i = 0; i < HAUTEUR; ++i)
	{
		for (j = 0; j < LARGEUR+1; ++j)
		{
			/*elimine pos_sokoban et caise*/
			if((l[i][j]==CAISSE)||(l[i][j]==SOKOBAN))
				m[i][j]=VIDE;
			else
				m[i][j]=l[i][j];
		}
	}
}

Boolean verif(grille g){
	int i;
	int j;
	int res=0;
	for (i = 0; i < HAUTEUR; ++i)
	{
		res=0;
		for (j = 0; j < LARGEUR+1; ++j)
		{
			res ++;
			if (g[i][j]=='\0'){
				printf("longueur ligne %d = %d\n",i,res );
				if (res!=LARGEUR+1)
					return TRUE;
			}
				
		}
	}
return FALSE;
}

int compte(grille g, char c){
	int i=0;
	int j;
	int res=0;
	for (i = 0; i < HAUTEUR; ++i)
	{
		for (j = 0; j < LARGEUR+1; ++j)
		{
			if (g[i][j]==c){
				res ++;
			}
				
		}
	}
	printf("nombre total de %c = %d\n",c,res );
	return res;
}

Boolean verifcompt(grille g){
	if (compte(g,CAISSE)!=compte(g,CIBLE))
	{
		return TRUE;
	}
	return FALSE;
}

void aide(){
	printf("commande \n");
	printf("z pour haut \n");
	printf("s pour bas \n");
	printf("d pour droite \n");
	printf("q pour gauche \n");
	printf("l pour leav\n");

}

void fgetgetstring(char getstring [MAXCH+1]){
	/*int i=0;*/
	if(fgets(getstring,MAXCH,stdin)==NULL)
		error(NO_GETSTRING);
	printf("%s\n",getstring );
	/*
	for (i = 0; getstring[i+1]!='\0'; ++i){
	switch(getstring[i]){
		case HELP : aide();
		break;
		case HAUT : printf("haut\n");
		break;

		case BAS : printf("bas\n");
		break;

		case DROITE : printf("droite\n");
		break;

		case GAUCHE : printf("gauche\n");
		break;

		printf("commande error\n");
		default : aide();
		break;
	}
	}*/
}

position pas(position spos,touche cmd){

  switch (cmd) {
     case HAUT:
        spos.x--;
        break;
     case BAS:
        spos.x++;
        break;
     case DROITE:
        spos.y++;
        break;
     case GAUCHE:
        spos.y--;
        break;
     default:
        error(PAUS_E);
        break;
  }
 
  return spos;
}

Boolean possible(grille dyn_g,position pos){ 
  if(pos.x < 0 || pos.x > HAUTEUR)
     return FALSE;
  else if(pos.y < 0 || pos.y > LARGEUR+1)
     return FALSE;
  else if(dyn_g[pos.x][pos.y] == MUR || dyn_g[pos.x][pos.y] == CAISSE)
     return FALSE;
  else return TRUE;
}

void deplace(grille dyn_g,position pos_a,position pos_b, grille old){
  dyn_g[pos_b.x][pos_b.y] = dyn_g[pos_a.x][pos_a.y];
  dyn_g[pos_a.x][pos_a.y]= old[pos_a.x][pos_a.y];
}

position joue(grille dyn, touche dir, position depart, grille dyn_g)
{
  position tmpos;
  position caissepos;
  printf("position de depart x=%d y=%d\n",depart.x, depart.y);
  /*depart.y--;
  depart.x--;*/

  tmpos=pas(depart,dir);
  printf("newpos x=%d y=%d\n", tmpos.x, tmpos.y);

  if(possible(dyn, tmpos) == FALSE)
  {
     if(dyn[tmpos.x][tmpos.y] == MUR)
        error(EMUR);
     else if(dyn[tmpos.x][tmpos.y] == CAISSE)
     {
        caissepos=pas(tmpos,dir);
        if(possible(dyn, caissepos) == FALSE)
           error(ECAISSE);
        else
        {
           deplace(dyn, tmpos, caissepos, dyn_g);
           deplace(dyn, depart, tmpos, dyn_g);
        }
     }
  }
  else {
     deplace(dyn, depart, tmpos, dyn_g);
  }
  return tmpos;
}

Boolean gagne(grille stat, position pos_soko, grille dyn_g){
  int x, y;
  for(y=0 ; y < HAUTEUR ; y++)
  {
     for(x=0 ; x < LARGEUR ; x++)
     {
        if(stat[y][x]==CIBLE)return FALSE;
        else if(dyn_g[y][x]==CIBLE && stat[y][x]==SOKOBAN)return FALSE;
     }
  }
  return TRUE;
}





/* lecture chaine caractere
int taille;
char tab [taille];
if(fgets(tab,taille,stdin)==NULL)
	error(io);*/





